document.getElementById('recipe-form').addEventListener('submit', async function (event) {
    event.preventDefault();
  
    // Get user input
    const ingredients = document.getElementById('ingredients').value;
  
    // Validate input
    if (!ingredients.trim()) {
        alert('Please enter some ingredients!');
        return;
    }
  
    // API URL and key (replace with your actual API details)
    const apiUrl = 'https://api.groq.com/openai/v1/chat/completions';
    const apiKey = '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';
  
    // Show a loading message
    const recipeOutput = document.getElementById('recipe-output');
    recipeOutput.innerHTML = '<p>Generating your recipe...</p>';
  
    try {
        // Make an API request
        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`,
            },
            body: JSON.stringify({
                model: "llama3-8b-8192",  // Model name
                messages: [
                    {
                        role: "user",  // The user role for the request
                        content: `I have the following ingredients: ${ingredients}. Can you generate a recipe?`
                    }
                ]
            }),
        });
  
        // Parse the response
        if (!response.ok) {
            throw new Error(`API error: ${response.statusText}`);
        }
  
        const data = await response.json();
  
        // Assuming the response has a 'recipe' field
        const recipeContent = data.choices?.[0]?.message?.content || null;

        if (recipeContent) {
            // Split the recipe content into different sections (assumption: steps and ingredients are separated by API or text structure)
            const recipeParts = recipeContent.split('\n').filter(part => part.trim() !== ''); // Split by line breaks and remove empty lines

            // Organize content into tables
            let ingredientsTable = '';
            let stepsTable = '';
            let isIngredientsSection = true;

            recipeParts.forEach(part => {
                if (part.toLowerCase().includes('step') || part.toLowerCase().includes('instruction')) {
                    isIngredientsSection = false; // Switch to steps section
                }

                if (isIngredientsSection) {
                    ingredientsTable += `<tr><td>${part}</td></tr>`;
                } else {
                    stepsTable += `<tr><td>${part}</td></tr>`;
                }
            });

            // Create the final organized HTML output
            const recipeHTML = `
                <h3>Here is your recipe:</h3>
                <table border="1" style="width: 100%; margin-bottom: 20px;">
                    <thead>
                        <tr><th>Ingredients</th></tr>
                    </thead>
                    <tbody>
                        ${ingredientsTable || '<tr><td>No ingredients provided.</td></tr>'}
                    </tbody>
                </table>
                <table border="1" style="width: 100%;">
                    <thead>
                        <tr><th>Steps</th></tr>
                    </thead>
                    <tbody>
                        ${stepsTable || '<tr><td>No steps provided.</td></tr>'}
                    </tbody>
                </table>
            `;

            recipeOutput.innerHTML = recipeHTML;
        } else {
            recipeOutput.textContent = 'Recipe not found. Try different ingredients!';
        }
    } catch (error) {
        console.error(error);
        recipeOutput.textContent = 'An error occurred while generating the recipe.';
    }
});
